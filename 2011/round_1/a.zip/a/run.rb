require 'a'

filename = ARGV.first

@a = A.new(filename)
@a.output